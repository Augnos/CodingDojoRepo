console.log("page loaded...");

// var mainVideo = document.getElementById("mainVideo");
// function over(element) {
//     play(element);
// }