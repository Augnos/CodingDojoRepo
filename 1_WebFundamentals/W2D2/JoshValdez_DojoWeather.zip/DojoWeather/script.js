console.log("page loading...")

function loading() {
    alert("Loading weather report...");
}

function acceptCookies(element) {
    element.remove(); 
}