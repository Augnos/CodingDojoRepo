console.log("test");

function liked(self) {
    self.innerText++;
}
